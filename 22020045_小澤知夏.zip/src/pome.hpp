//
//  pome.hpp
//  intermediate_works
//
//  Created by OzawaChinatsu on 2021/11/15.
//

#ifndef pome_hpp
#define pome_hpp

#include <stdio.h>

#endif /* pome_hpp */

class pome{
    
    public:
        void setup();
        void update();
        void draw();
        
};
